$(document).ready(function(){
    var url = 1;
    var img='';
    var titlr= '';
    var author='1212S';

    $.get("https://www.googleapis.com/books/v1", function(response){})
    console.log(response)

});