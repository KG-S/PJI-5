const express = require("express");
const app = express();


app.use(express.static('public'));





app.get("/", function(req, res){
    res.sendFile(__dirname+"/public/html/index.html");
});

app.get("/Login", function(req, res){
    res.sendfile(__dirname+"/public/html/entrar.html");
});

app.get('/Cadastro', function(req, res){
    res.sendfile(__dirname+"/public/html/cadastro.html");
});

app.get('/blog', function(req, res){
    res.sendfile(__dirname+"/public/html/pwpw.html");
});








app.listen(10001, function(){
    console.log("servidor rodando na url http://localhost:10001");
})

